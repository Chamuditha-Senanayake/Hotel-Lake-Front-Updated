﻿
namespace GuestTab
{
    partial class Food
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelDesktop = new System.Windows.Forms.Panel();
            this.radioBeverage = new System.Windows.Forms.RadioButton();
            this.radioSnacks = new System.Windows.Forms.RadioButton();
            this.radioDess = new System.Windows.Forms.RadioButton();
            this.radioBreak = new System.Windows.Forms.RadioButton();
            this.radioLunch = new System.Windows.Forms.RadioButton();
            this.radioDinner = new System.Windows.Forms.RadioButton();
            this.radioAnytime = new System.Windows.Forms.RadioButton();
            this.iconBttnFoodSearchCashier = new FontAwesome.Sharp.IconButton();
            this.txtSearchFood = new System.Windows.Forms.TextBox();
            this.num1 = new System.Windows.Forms.NumericUpDown();
            this.iconBttnAddFood = new FontAwesome.Sharp.IconButton();
            this.lblFood = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.lblFTotal = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.btnOrder = new System.Windows.Forms.Button();
            this.tbleOrderDetails = new System.Windows.Forms.DataGridView();
            this.FoodNamePayments = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QuantityPayments = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FoodPricePayments = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FoodSelectPayments = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.lblOrderNumber = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tblFoodDetails = new System.Windows.Forms.DataGridView();
            this.btnContacts = new FontAwesome.Sharp.IconButton();
            this.btnBill = new FontAwesome.Sharp.IconButton();
            this.btnServices = new FontAwesome.Sharp.IconButton();
            this.btnHome = new FontAwesome.Sharp.IconButton();
            this.btnActivity = new FontAwesome.Sharp.IconButton();
            this.btnFood = new FontAwesome.Sharp.IconButton();
            this.btnCleaning = new FontAwesome.Sharp.IconButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelDesktop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbleOrderDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblFoodDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelDesktop
            // 
            this.panelDesktop.Controls.Add(this.radioBeverage);
            this.panelDesktop.Controls.Add(this.radioSnacks);
            this.panelDesktop.Controls.Add(this.radioDess);
            this.panelDesktop.Controls.Add(this.radioBreak);
            this.panelDesktop.Controls.Add(this.radioLunch);
            this.panelDesktop.Controls.Add(this.radioDinner);
            this.panelDesktop.Controls.Add(this.radioAnytime);
            this.panelDesktop.Controls.Add(this.iconBttnFoodSearchCashier);
            this.panelDesktop.Controls.Add(this.txtSearchFood);
            this.panelDesktop.Controls.Add(this.num1);
            this.panelDesktop.Controls.Add(this.iconBttnAddFood);
            this.panelDesktop.Controls.Add(this.lblFood);
            this.panelDesktop.Controls.Add(this.panel5);
            this.panelDesktop.Controls.Add(this.panel4);
            this.panelDesktop.Controls.Add(this.label4);
            this.panelDesktop.Controls.Add(this.lblFTotal);
            this.panelDesktop.Controls.Add(this.checkBox1);
            this.panelDesktop.Controls.Add(this.btnOrder);
            this.panelDesktop.Controls.Add(this.tbleOrderDetails);
            this.panelDesktop.Controls.Add(this.lblOrderNumber);
            this.panelDesktop.Controls.Add(this.label1);
            this.panelDesktop.Controls.Add(this.tblFoodDetails);
            this.panelDesktop.Controls.Add(this.btnContacts);
            this.panelDesktop.Controls.Add(this.btnBill);
            this.panelDesktop.Controls.Add(this.btnServices);
            this.panelDesktop.Controls.Add(this.btnHome);
            this.panelDesktop.Controls.Add(this.btnActivity);
            this.panelDesktop.Controls.Add(this.btnFood);
            this.panelDesktop.Controls.Add(this.btnCleaning);
            this.panelDesktop.Controls.Add(this.pictureBox1);
            this.panelDesktop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDesktop.Location = new System.Drawing.Point(0, 0);
            this.panelDesktop.Name = "panelDesktop";
            this.panelDesktop.Size = new System.Drawing.Size(1231, 713);
            this.panelDesktop.TabIndex = 0;
            // 
            // radioBeverage
            // 
            this.radioBeverage.AutoSize = true;
            this.radioBeverage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(227)))), ((int)(((byte)(233)))));
            this.radioBeverage.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBeverage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(62)))), ((int)(((byte)(70)))));
            this.radioBeverage.Location = new System.Drawing.Point(14, 452);
            this.radioBeverage.Name = "radioBeverage";
            this.radioBeverage.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            this.radioBeverage.Size = new System.Drawing.Size(195, 62);
            this.radioBeverage.TabIndex = 462;
            this.radioBeverage.TabStop = true;
            this.radioBeverage.Text = "Beverages";
            this.radioBeverage.UseVisualStyleBackColor = false;
            this.radioBeverage.CheckedChanged += new System.EventHandler(this.radioBeverage_CheckedChanged);
            this.radioBeverage.MouseDown += new System.Windows.Forms.MouseEventHandler(this.radioBeverage_MouseDown);
            // 
            // radioSnacks
            // 
            this.radioSnacks.AutoSize = true;
            this.radioSnacks.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(227)))), ((int)(((byte)(233)))));
            this.radioSnacks.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioSnacks.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(62)))), ((int)(((byte)(70)))));
            this.radioSnacks.Location = new System.Drawing.Point(14, 620);
            this.radioSnacks.Name = "radioSnacks";
            this.radioSnacks.Padding = new System.Windows.Forms.Padding(0, 10, 48, 10);
            this.radioSnacks.Size = new System.Drawing.Size(195, 62);
            this.radioSnacks.TabIndex = 461;
            this.radioSnacks.TabStop = true;
            this.radioSnacks.Text = "Sancks";
            this.radioSnacks.UseVisualStyleBackColor = false;
            this.radioSnacks.CheckedChanged += new System.EventHandler(this.radioSnacks_CheckedChanged);
            this.radioSnacks.MouseDown += new System.Windows.Forms.MouseEventHandler(this.radioSnacks_MouseDown);
            // 
            // radioDess
            // 
            this.radioDess.AutoSize = true;
            this.radioDess.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(227)))), ((int)(((byte)(233)))));
            this.radioDess.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioDess.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(62)))), ((int)(((byte)(70)))));
            this.radioDess.Location = new System.Drawing.Point(14, 534);
            this.radioDess.Name = "radioDess";
            this.radioDess.Padding = new System.Windows.Forms.Padding(0, 10, 28, 10);
            this.radioDess.Size = new System.Drawing.Size(197, 62);
            this.radioDess.TabIndex = 460;
            this.radioDess.TabStop = true;
            this.radioDess.Text = "Desserts";
            this.radioDess.UseVisualStyleBackColor = false;
            this.radioDess.CheckedChanged += new System.EventHandler(this.radioDess_CheckedChanged);
            this.radioDess.MouseDown += new System.Windows.Forms.MouseEventHandler(this.radioDess_MouseDown);
            // 
            // radioBreak
            // 
            this.radioBreak.AutoSize = true;
            this.radioBreak.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(227)))), ((int)(((byte)(233)))));
            this.radioBreak.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBreak.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(62)))), ((int)(((byte)(70)))));
            this.radioBreak.Location = new System.Drawing.Point(14, 214);
            this.radioBreak.Name = "radioBreak";
            this.radioBreak.Padding = new System.Windows.Forms.Padding(0, 10, 20, 10);
            this.radioBreak.Size = new System.Drawing.Size(197, 62);
            this.radioBreak.TabIndex = 459;
            this.radioBreak.TabStop = true;
            this.radioBreak.Text = "Breakfast";
            this.radioBreak.UseVisualStyleBackColor = false;
            this.radioBreak.CheckedChanged += new System.EventHandler(this.radioBreak_CheckedChanged);
            this.radioBreak.MouseDown += new System.Windows.Forms.MouseEventHandler(this.radioBreak_MouseDown);
            // 
            // radioLunch
            // 
            this.radioLunch.AutoSize = true;
            this.radioLunch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(227)))), ((int)(((byte)(233)))));
            this.radioLunch.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioLunch.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(62)))), ((int)(((byte)(70)))));
            this.radioLunch.Location = new System.Drawing.Point(14, 292);
            this.radioLunch.Name = "radioLunch";
            this.radioLunch.Padding = new System.Windows.Forms.Padding(0, 10, 68, 10);
            this.radioLunch.Size = new System.Drawing.Size(195, 62);
            this.radioLunch.TabIndex = 458;
            this.radioLunch.TabStop = true;
            this.radioLunch.Text = "Lunch";
            this.radioLunch.UseVisualStyleBackColor = false;
            this.radioLunch.CheckedChanged += new System.EventHandler(this.radioLunch_CheckedChanged);
            this.radioLunch.MouseDown += new System.Windows.Forms.MouseEventHandler(this.radioLunch_MouseDown);
            // 
            // radioDinner
            // 
            this.radioDinner.AutoSize = true;
            this.radioDinner.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(227)))), ((int)(((byte)(233)))));
            this.radioDinner.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioDinner.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(62)))), ((int)(((byte)(70)))));
            this.radioDinner.Location = new System.Drawing.Point(14, 371);
            this.radioDinner.Name = "radioDinner";
            this.radioDinner.Padding = new System.Windows.Forms.Padding(0, 10, 59, 10);
            this.radioDinner.Size = new System.Drawing.Size(193, 62);
            this.radioDinner.TabIndex = 457;
            this.radioDinner.TabStop = true;
            this.radioDinner.Text = "Dinner";
            this.radioDinner.UseVisualStyleBackColor = false;
            this.radioDinner.CheckedChanged += new System.EventHandler(this.radioDinner_CheckedChanged);
            this.radioDinner.MouseDown += new System.Windows.Forms.MouseEventHandler(this.radioDinner_MouseDown);
            // 
            // radioAnytime
            // 
            this.radioAnytime.AutoSize = true;
            this.radioAnytime.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(227)))), ((int)(((byte)(233)))));
            this.radioAnytime.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioAnytime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(62)))), ((int)(((byte)(70)))));
            this.radioAnytime.Location = new System.Drawing.Point(14, 134);
            this.radioAnytime.Name = "radioAnytime";
            this.radioAnytime.Padding = new System.Windows.Forms.Padding(0, 10, 40, 10);
            this.radioAnytime.Size = new System.Drawing.Size(196, 62);
            this.radioAnytime.TabIndex = 456;
            this.radioAnytime.TabStop = true;
            this.radioAnytime.Text = "Anytime";
            this.radioAnytime.UseVisualStyleBackColor = false;
            this.radioAnytime.CheckedChanged += new System.EventHandler(this.radioAnytime_CheckedChanged);
            this.radioAnytime.MouseDown += new System.Windows.Forms.MouseEventHandler(this.radioAnytime_MouseDown);
            // 
            // iconBttnFoodSearchCashier
            // 
            this.iconBttnFoodSearchCashier.Enabled = false;
            this.iconBttnFoodSearchCashier.IconChar = FontAwesome.Sharp.IconChar.Search;
            this.iconBttnFoodSearchCashier.IconColor = System.Drawing.Color.Black;
            this.iconBttnFoodSearchCashier.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBttnFoodSearchCashier.IconSize = 30;
            this.iconBttnFoodSearchCashier.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.iconBttnFoodSearchCashier.Location = new System.Drawing.Point(647, 128);
            this.iconBttnFoodSearchCashier.Name = "iconBttnFoodSearchCashier";
            this.iconBttnFoodSearchCashier.Size = new System.Drawing.Size(34, 31);
            this.iconBttnFoodSearchCashier.TabIndex = 455;
            this.iconBttnFoodSearchCashier.UseVisualStyleBackColor = true;
            // 
            // txtSearchFood
            // 
            this.txtSearchFood.ForeColor = System.Drawing.Color.Gray;
            this.txtSearchFood.Location = new System.Drawing.Point(324, 132);
            this.txtSearchFood.Name = "txtSearchFood";
            this.txtSearchFood.Size = new System.Drawing.Size(293, 22);
            this.txtSearchFood.TabIndex = 454;
            this.txtSearchFood.Text = "Search";
            this.txtSearchFood.TextChanged += new System.EventHandler(this.txtSearchFood_TextChanged);
            this.txtSearchFood.Enter += new System.EventHandler(this.txtSearchFood_Enter);
            // 
            // num1
            // 
            this.num1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.num1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            this.num1.Location = new System.Drawing.Point(1104, 180);
            this.num1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.num1.Name = "num1";
            this.num1.Size = new System.Drawing.Size(50, 49);
            this.num1.TabIndex = 452;
            this.num1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // iconBttnAddFood
            // 
            this.iconBttnAddFood.FlatAppearance.BorderSize = 0;
            this.iconBttnAddFood.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.iconBttnAddFood.ForeColor = System.Drawing.Color.Transparent;
            this.iconBttnAddFood.IconChar = FontAwesome.Sharp.IconChar.PlusCircle;
            this.iconBttnAddFood.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            this.iconBttnAddFood.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBttnAddFood.IconSize = 35;
            this.iconBttnAddFood.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.iconBttnAddFood.Location = new System.Drawing.Point(1160, 183);
            this.iconBttnAddFood.Name = "iconBttnAddFood";
            this.iconBttnAddFood.Size = new System.Drawing.Size(40, 43);
            this.iconBttnAddFood.TabIndex = 451;
            this.iconBttnAddFood.UseVisualStyleBackColor = true;
            this.iconBttnAddFood.Click += new System.EventHandler(this.iconBttnAddFood_Click);
            // 
            // lblFood
            // 
            this.lblFood.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFood.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFood.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            this.lblFood.Location = new System.Drawing.Point(826, 190);
            this.lblFood.Name = "lblFood";
            this.lblFood.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblFood.Size = new System.Drawing.Size(244, 30);
            this.lblFood.TabIndex = 44;
            this.lblFood.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            this.panel5.Location = new System.Drawing.Point(795, 132);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1, 567);
            this.panel5.TabIndex = 40;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            this.panel4.Location = new System.Drawing.Point(233, 132);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1, 567);
            this.panel4.TabIndex = 39;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            this.label4.Location = new System.Drawing.Point(824, 135);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 29);
            this.label4.TabIndex = 54;
            this.label4.Text = "My Bill";
            // 
            // lblFTotal
            // 
            this.lblFTotal.AutoSize = true;
            this.lblFTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(227)))), ((int)(((byte)(233)))));
            this.lblFTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(62)))), ((int)(((byte)(70)))));
            this.lblFTotal.Location = new System.Drawing.Point(864, 571);
            this.lblFTotal.Name = "lblFTotal";
            this.lblFTotal.Size = new System.Drawing.Size(90, 24);
            this.lblFTotal.TabIndex = 53;
            this.lblFTotal.Text = "4500 LKR";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            this.checkBox1.Location = new System.Drawing.Point(972, 573);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(191, 21);
            this.checkBox1.TabIndex = 52;
            this.checkBox1.Text = "Add this amount to my bill";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // btnOrder
            // 
            this.btnOrder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            this.btnOrder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrder.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.btnOrder.Location = new System.Drawing.Point(826, 611);
            this.btnOrder.Name = "btnOrder";
            this.btnOrder.Size = new System.Drawing.Size(374, 60);
            this.btnOrder.TabIndex = 51;
            this.btnOrder.Text = "Place my Order";
            this.btnOrder.UseVisualStyleBackColor = false;
            this.btnOrder.Click += new System.EventHandler(this.btnOrder_Click);
            // 
            // tbleOrderDetails
            // 
            this.tbleOrderDetails.AllowUserToResizeColumns = false;
            this.tbleOrderDetails.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbleOrderDetails.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.tbleOrderDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.tbleOrderDetails.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(227)))), ((int)(((byte)(233)))));
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(62)))), ((int)(((byte)(70)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.tbleOrderDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.tbleOrderDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tbleOrderDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.FoodNamePayments,
            this.QuantityPayments,
            this.FoodPricePayments,
            this.FoodSelectPayments});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.tbleOrderDetails.DefaultCellStyle = dataGridViewCellStyle3;
            this.tbleOrderDetails.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.tbleOrderDetails.Location = new System.Drawing.Point(826, 242);
            this.tbleOrderDetails.Name = "tbleOrderDetails";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.tbleOrderDetails.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.tbleOrderDetails.RowHeadersVisible = false;
            this.tbleOrderDetails.RowHeadersWidth = 51;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            this.tbleOrderDetails.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.tbleOrderDetails.RowTemplate.Height = 35;
            this.tbleOrderDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.tbleOrderDetails.Size = new System.Drawing.Size(378, 304);
            this.tbleOrderDetails.TabIndex = 50;
            this.tbleOrderDetails.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.tbleOrderDetails_CellContentClick);
            this.tbleOrderDetails.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.tbleOrderDetails_CellMouseUp);
            this.tbleOrderDetails.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.tbleOrderDetails_RowsRemoved);
            // 
            // FoodNamePayments
            // 
            this.FoodNamePayments.HeaderText = "Name";
            this.FoodNamePayments.MinimumWidth = 6;
            this.FoodNamePayments.Name = "FoodNamePayments";
            // 
            // QuantityPayments
            // 
            this.QuantityPayments.HeaderText = "Quantity";
            this.QuantityPayments.MinimumWidth = 6;
            this.QuantityPayments.Name = "QuantityPayments";
            // 
            // FoodPricePayments
            // 
            this.FoodPricePayments.HeaderText = "Price";
            this.FoodPricePayments.MinimumWidth = 6;
            this.FoodPricePayments.Name = "FoodPricePayments";
            // 
            // FoodSelectPayments
            // 
            this.FoodSelectPayments.HeaderText = "";
            this.FoodSelectPayments.MinimumWidth = 6;
            this.FoodSelectPayments.Name = "FoodSelectPayments";
            // 
            // lblOrderNumber
            // 
            this.lblOrderNumber.AutoSize = true;
            this.lblOrderNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrderNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.lblOrderNumber.Location = new System.Drawing.Point(1169, 152);
            this.lblOrderNumber.Name = "lblOrderNumber";
            this.lblOrderNumber.Size = new System.Drawing.Size(35, 18);
            this.lblOrderNumber.TabIndex = 49;
            this.lblOrderNumber.Text = "005";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.label1.Location = new System.Drawing.Point(1055, 151);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 18);
            this.label1.TabIndex = 48;
            this.label1.Text = "Order Number";
            // 
            // tblFoodDetails
            // 
            this.tblFoodDetails.AllowUserToAddRows = false;
            this.tblFoodDetails.AllowUserToDeleteRows = false;
            this.tblFoodDetails.AllowUserToResizeColumns = false;
            this.tblFoodDetails.AllowUserToResizeRows = false;
            this.tblFoodDetails.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(227)))), ((int)(((byte)(233)))));
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(62)))), ((int)(((byte)(70)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.tblFoodDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.tblFoodDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.tblFoodDetails.DefaultCellStyle = dataGridViewCellStyle7;
            this.tblFoodDetails.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.tblFoodDetails.Location = new System.Drawing.Point(263, 180);
            this.tblFoodDetails.Name = "tblFoodDetails";
            this.tblFoodDetails.ReadOnly = true;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.tblFoodDetails.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.tblFoodDetails.RowHeadersVisible = false;
            this.tblFoodDetails.RowHeadersWidth = 60;
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(181)))));
            this.tblFoodDetails.RowsDefaultCellStyle = dataGridViewCellStyle9;
            this.tblFoodDetails.RowTemplate.Height = 35;
            this.tblFoodDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.tblFoodDetails.Size = new System.Drawing.Size(502, 491);
            this.tblFoodDetails.TabIndex = 47;
            this.tblFoodDetails.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.tblFoodDetails_CellClick);
            this.tblFoodDetails.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridFoods_CellContentClick);
            // 
            // btnContacts
            // 
            this.btnContacts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(227)))), ((int)(((byte)(233)))));
            this.btnContacts.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnContacts.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.btnContacts.IconChar = FontAwesome.Sharp.IconChar.PhoneVolume;
            this.btnContacts.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.btnContacts.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnContacts.IconSize = 70;
            this.btnContacts.Location = new System.Drawing.Point(1029, 16);
            this.btnContacts.Name = "btnContacts";
            this.btnContacts.Size = new System.Drawing.Size(175, 81);
            this.btnContacts.TabIndex = 38;
            this.btnContacts.UseVisualStyleBackColor = false;
            this.btnContacts.Click += new System.EventHandler(this.btnContacts_Click);
            // 
            // btnBill
            // 
            this.btnBill.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(227)))), ((int)(((byte)(233)))));
            this.btnBill.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBill.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.btnBill.IconChar = FontAwesome.Sharp.IconChar.Paypal;
            this.btnBill.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.btnBill.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnBill.IconSize = 70;
            this.btnBill.Location = new System.Drawing.Point(848, 16);
            this.btnBill.Name = "btnBill";
            this.btnBill.Size = new System.Drawing.Size(175, 81);
            this.btnBill.TabIndex = 37;
            this.btnBill.UseVisualStyleBackColor = false;
            this.btnBill.Click += new System.EventHandler(this.btnBill_Click);
            // 
            // btnServices
            // 
            this.btnServices.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(227)))), ((int)(((byte)(233)))));
            this.btnServices.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnServices.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.btnServices.IconChar = FontAwesome.Sharp.IconChar.HotTub;
            this.btnServices.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.btnServices.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnServices.IconSize = 70;
            this.btnServices.Location = new System.Drawing.Point(667, 16);
            this.btnServices.Name = "btnServices";
            this.btnServices.Size = new System.Drawing.Size(175, 81);
            this.btnServices.TabIndex = 36;
            this.btnServices.UseVisualStyleBackColor = false;
            this.btnServices.Click += new System.EventHandler(this.btnServices_Click);
            // 
            // btnHome
            // 
            this.btnHome.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(227)))), ((int)(((byte)(233)))));
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.btnHome.IconChar = FontAwesome.Sharp.IconChar.Home;
            this.btnHome.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.btnHome.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnHome.IconSize = 70;
            this.btnHome.Location = new System.Drawing.Point(19, 16);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(99, 81);
            this.btnHome.TabIndex = 32;
            this.btnHome.UseVisualStyleBackColor = false;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // btnActivity
            // 
            this.btnActivity.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(227)))), ((int)(((byte)(233)))));
            this.btnActivity.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnActivity.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.btnActivity.IconChar = FontAwesome.Sharp.IconChar.History;
            this.btnActivity.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.btnActivity.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnActivity.IconSize = 70;
            this.btnActivity.Location = new System.Drawing.Point(486, 16);
            this.btnActivity.Name = "btnActivity";
            this.btnActivity.Size = new System.Drawing.Size(175, 81);
            this.btnActivity.TabIndex = 35;
            this.btnActivity.UseVisualStyleBackColor = false;
            this.btnActivity.Click += new System.EventHandler(this.btnActivity_Click);
            // 
            // btnFood
            // 
            this.btnFood.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(227)))), ((int)(((byte)(233)))));
            this.btnFood.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFood.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.btnFood.IconChar = FontAwesome.Sharp.IconChar.MugHot;
            this.btnFood.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.btnFood.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnFood.IconSize = 70;
            this.btnFood.Location = new System.Drawing.Point(124, 16);
            this.btnFood.Name = "btnFood";
            this.btnFood.Size = new System.Drawing.Size(175, 81);
            this.btnFood.TabIndex = 33;
            this.btnFood.UseVisualStyleBackColor = false;
            this.btnFood.Click += new System.EventHandler(this.btnFood_Click);
            // 
            // btnCleaning
            // 
            this.btnCleaning.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(227)))), ((int)(((byte)(233)))));
            this.btnCleaning.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCleaning.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.btnCleaning.IconChar = FontAwesome.Sharp.IconChar.PeopleCarry;
            this.btnCleaning.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.btnCleaning.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnCleaning.IconSize = 70;
            this.btnCleaning.Location = new System.Drawing.Point(305, 16);
            this.btnCleaning.Name = "btnCleaning";
            this.btnCleaning.Size = new System.Drawing.Size(175, 81);
            this.btnCleaning.TabIndex = 34;
            this.btnCleaning.UseVisualStyleBackColor = false;
            this.btnCleaning.Click += new System.EventHandler(this.btnCleaning_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1231, 713);
            this.pictureBox1.TabIndex = 55;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Food
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.ClientSize = new System.Drawing.Size(1231, 713);
            this.Controls.Add(this.panelDesktop);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Food";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Contact";
            this.Load += new System.EventHandler(this.Food_Load);
            this.panelDesktop.ResumeLayout(false);
            this.panelDesktop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbleOrderDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblFoodDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelDesktop;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblFTotal;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button btnOrder;
        private System.Windows.Forms.DataGridView tbleOrderDetails;
        private System.Windows.Forms.Label lblOrderNumber;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView tblFoodDetails;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private FontAwesome.Sharp.IconButton btnContacts;
        private FontAwesome.Sharp.IconButton btnBill;
        private FontAwesome.Sharp.IconButton btnServices;
        private FontAwesome.Sharp.IconButton btnHome;
        private FontAwesome.Sharp.IconButton btnActivity;
        private FontAwesome.Sharp.IconButton btnFood;
        private FontAwesome.Sharp.IconButton btnCleaning;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.NumericUpDown num1;
        private FontAwesome.Sharp.IconButton iconBttnAddFood;
        private System.Windows.Forms.Label lblFood;
        private FontAwesome.Sharp.IconButton iconBttnFoodSearchCashier;
        private System.Windows.Forms.TextBox txtSearchFood;
        private System.Windows.Forms.RadioButton radioAnytime;
        private System.Windows.Forms.RadioButton radioBeverage;
        private System.Windows.Forms.RadioButton radioSnacks;
        private System.Windows.Forms.RadioButton radioDess;
        private System.Windows.Forms.RadioButton radioBreak;
        private System.Windows.Forms.RadioButton radioLunch;
        private System.Windows.Forms.RadioButton radioDinner;
        private System.Windows.Forms.DataGridViewTextBoxColumn FoodNamePayments;
        private System.Windows.Forms.DataGridViewTextBoxColumn QuantityPayments;
        private System.Windows.Forms.DataGridViewTextBoxColumn FoodPricePayments;
        private System.Windows.Forms.DataGridViewCheckBoxColumn FoodSelectPayments;
    }
}