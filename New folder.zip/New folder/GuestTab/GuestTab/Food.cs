﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace GuestTab
{
    public partial class Food : Form
    {
        private Form currentChildForm;
        public Food()
        {
            InitializeComponent();
        }

        private void OpenChildForm(Form childForm)
        {
            //open only form
            if (currentChildForm != null)
            {
                currentChildForm.Close();
            }
            currentChildForm = childForm;
            //End
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelDesktop.Controls.Add(childForm);
            panelDesktop.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        //from main

        private MySqlConnection dbQuery()
        {
            DBConnection dBclass = new DBConnection();
            MySqlConnection conn = dBclass.getConnection();
            return conn;
        }

        //data adapter
        private void DataAdapter(String sql, MySqlConnection conn)
        {
            MySqlDataAdapter adapter = new MySqlDataAdapter(sql, conn);

            DataSet ds = new DataSet();
            adapter.Fill(ds, "food");
            tblFoodDetails.DataSource = ds.Tables["food"];
            conn.Close();
        }

        //data reader
        private string DataReader1(string sql, MySqlConnection conn)
        {
            string output = "";
            MySqlCommand command = new MySqlCommand(sql, conn);
            MySqlDataReader dataReader = command.ExecuteReader();
            while (dataReader.Read())
            {
                output += dataReader.GetValue(0).ToString();
            }
            conn.Close();
            return output;
        }

        //data adder
        private void DataAdder(string sql, MySqlConnection conn)
        {
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            adapter.InsertCommand = new MySqlCommand(sql, conn);
            adapter.InsertCommand.ExecuteNonQuery();
            conn.Close();
        }

        //from main

        private void Food_Load(object sender, EventArgs e)
        {
            btnFood.IconColor = Color.FromArgb(227, 253, 253);
            btnFood.ForeColor = Color.FromArgb(57, 62, 70);
            btnFood.BackColor = Color.FromArgb(0, 173, 181);

            try
            {
                string sql = "CALL getAllFood";
                DataAdapter(sql, dbQuery());

                tbleOrderDetails.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                tblFoodDetails.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                tblFoodDetails.EnableHeadersVisualStyles = false;
                tblFoodDetails.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(227, 253, 253);
                tbleOrderDetails.EnableHeadersVisualStyles = false;
                tbleOrderDetails.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(227, 253, 253);
                tblFoodDetails.Columns[0].Width =60;
                tblFoodDetails.Columns[1].Width = 300;
                tblFoodDetails.Columns[2].Width = 118;

                tbleOrderDetails.Columns[0].Width = 200;
                tbleOrderDetails.Columns[1].Width = 75;
                tbleOrderDetails.Columns[3].Width = 30;
                //tbleOrderDetails.Columns[2].Width = 80;
                lblFTotal.Text = "0.00";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


  

        private void btnHome_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Main());
        }

        private void btnFood_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Food());
        }

        private void btnCleaning_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Cleaning());
        }

        private void btnActivity_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Activity());
        }

        private void btnServices_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Services());
        }

        private void btnBill_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Bill());
        }

        private void btnContacts_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Contact());
        }

        private void gridFoods_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        //from main
        private void txtSearchFood_Enter(object sender, EventArgs e)
        {
            if (txtSearchFood.Text == "Search")
            {
                txtSearchFood.Text = "";
                txtSearchFood.ForeColor = Color.Black;
            }
        }

        private void txtSearchFood_TextChanged(object sender, EventArgs e)
        {
            radioAnytime.Checked = false;
            radioBreak.Checked = false;
            radioLunch.Checked = false;
            radioDinner.Checked = false;
            radioAnytime.Checked = false;
            radioDess.Checked = false;
            radioSnacks.Checked = false;

            try
            {
                string sql = "CALL getSelectedFoodbyName('%" + txtSearchFood.Text + "%')";
                DataAdapter(sql, dbQuery());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void radioAnytime_CheckedChanged(object sender, EventArgs e)
        {
            if (radioAnytime.Checked)
            {

                try
                {
                    string sql = "CALL getSelectedFood('123')";
                    DataAdapter(sql, dbQuery());

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void radioBreak_CheckedChanged(object sender, EventArgs e)
        {
            if (radioBreak.Checked)
            {

                try
                {
                    string sql = "CALL getSelectedFood('%1%')";
                    DataAdapter(sql, dbQuery());

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void radioBeverage_CheckedChanged(object sender, EventArgs e)
        {
            if (radioBeverage.Checked)
            {
                try
                {
                    string sql = "CALL getSelectedFood('4')";
                    DataAdapter(sql, dbQuery());

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void radioDess_CheckedChanged(object sender, EventArgs e)
        {
            if (radioDess.Checked)
            {
                try
                {
                    string sql = "CALL getSelectedFood('5')";
                    DataAdapter(sql, dbQuery());

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void radioLunch_CheckedChanged(object sender, EventArgs e)
        {
            if (radioLunch.Checked)
            {

                try
                {
                    string sql = "CALL getSelectedFood('%2%')";
                    DataAdapter(sql, dbQuery());

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void radioDinner_CheckedChanged(object sender, EventArgs e)
        {
            if (radioDinner.Checked)
            {
                try
                {
                    string sql = "CALL getSelectedFood('%3%')";
                    DataAdapter(sql, dbQuery());

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void radioSnacks_CheckedChanged(object sender, EventArgs e)
        {
            if (radioSnacks.Checked)
            {
                try
                {
                    string sql = "CALL getSelectedFood('6')";
                    DataAdapter(sql, dbQuery());

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void radioAnytime_MouseDown(object sender, MouseEventArgs e)
        {
            txtSearchFood.Text = "Search";
            txtSearchFood.ForeColor = Color.Gray;
        }

        private void radioBreak_MouseDown(object sender, MouseEventArgs e)
        {
            txtSearchFood.Text = "Search";
            txtSearchFood.ForeColor = Color.Gray;
        }

        private void radioLunch_MouseDown(object sender, MouseEventArgs e)
        {
            txtSearchFood.Text = "Search";
            txtSearchFood.ForeColor = Color.Gray;
        }

        private void radioDinner_MouseDown(object sender, MouseEventArgs e)
        {
            txtSearchFood.Text = "Search";
            txtSearchFood.ForeColor = Color.Gray;
        }

        private void radioBeverage_MouseDown(object sender, MouseEventArgs e)
        {
            txtSearchFood.Text = "Search";
            txtSearchFood.ForeColor = Color.Gray;
        }

        private void radioDess_MouseDown(object sender, MouseEventArgs e)
        {
            txtSearchFood.Text = "Search";
            txtSearchFood.ForeColor = Color.Gray;
        }

        private void radioSnacks_MouseDown(object sender, MouseEventArgs e)
        {
            txtSearchFood.Text = "Search";
            txtSearchFood.ForeColor = Color.Gray;
        }

        private void tblFoodDetails_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                string FID = tblFoodDetails.Rows[e.RowIndex].Cells[0].Value.ToString();
                lblFood.Text = tblFoodDetails.Rows[e.RowIndex].Cells[1].Value.ToString();
            }
            catch(Exception ex)
            {

            }

        }

        private void iconBttnAddFood_Click(object sender, EventArgs e)
        {
            if (lblFood.Text == "")
            {
                MessageBox.Show("Select Food Item ", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            else
            {
                string fPrice = DataReader1("SELECT FoodPrice FROM food WHERE FoodName = '" + lblFood.Text + "'", dbQuery());
                tbleOrderDetails.Rows.Add(lblFood.Text, num1.Value, fPrice, true);

                int P = 0;

                for (int i = 0; i < tbleOrderDetails.RowCount; i++)
                {
                    bool x = Convert.ToBoolean(tbleOrderDetails.Rows[i].Cells[3].Value);
                    if (x == true)
                    {
                        P += Convert.ToInt32(tbleOrderDetails.Rows[i].Cells["FoodPricePayments"].Value.ToString()) * Convert.ToInt32(tbleOrderDetails.Rows[i].Cells["QuantityPayments"].Value.ToString());
                        lblFTotal.Text = P.ToString();
                    }
                }

            }
        }

        private void tbleOrderDetails_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                int P = 0;

                for (int i = 0; i < tbleOrderDetails.RowCount; i++)
                {
                    bool x = Convert.ToBoolean(tbleOrderDetails.Rows[i].Cells[3].Value);

                    if (x == true)
                    {
                        P += Convert.ToInt32(tbleOrderDetails.Rows[i].Cells["FoodPricePayments"].Value.ToString()) * Convert.ToInt32(tbleOrderDetails.Rows[i].Cells["QuantityPayments"].Value.ToString());
                        lblFTotal.Text = P.ToString();
                    }

                    else
                    {
                        tbleOrderDetails.Rows.Remove(tbleOrderDetails.Rows[i]);
                    }
                }

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }
        }

        private void tbleOrderDetails_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            int P = 0;

            for (int i = 0; i < tbleOrderDetails.RowCount; i++)
            {
                bool x = Convert.ToBoolean(tbleOrderDetails.Rows[i].Cells[3].Value);
                if (x == true)
                {
                    P += Convert.ToInt32(tbleOrderDetails.Rows[i].Cells["FoodPricePayments"].Value.ToString()) * Convert.ToInt32(tbleOrderDetails.Rows[i].Cells["QuantityPayments"].Value.ToString());
                    lblFTotal.Text = P.ToString();
                }
            }
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            DialogResult reslult = MessageBox.Show("Do you want to complete the order?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            string billID = "SELECT MAX(OrderID) FROM food_order";
            string billID2 = DataReader1(billID, dbQuery());
            int BID = (int.Parse(billID2)) + 1;

            if (reslult == DialogResult.Yes)
            {
                for (int i = 0; i < tbleOrderDetails.RowCount; i++)
                {
                    bool x = Convert.ToBoolean(tbleOrderDetails.Rows[i].Cells[3].Value);
                    if (x == true)
                    {
                        string foodID = DataReader1("SELECT FoodID FROM food WHERE FoodName = '" + tbleOrderDetails.Rows[i].Cells["FoodNamePayments"].Value.ToString() + "'", dbQuery());

                        DateTimePicker dateTimePicker1 = new DateTimePicker();
                        // dateTimePicker1.Value. dateTime.Now.ToString("yyyy-MM-dd HH:mm");
                        //DateTime.Now.ToString("yyyy-MM-dd HH:mm");


                        string date = DateTime.Now.ToString("yyyy-MM-dd HH:mm");

                        int Quantity = Convert.ToInt32(tbleOrderDetails.Rows[i].Cells["QuantityPayments"].Value.ToString());

                        string sql = "INSERT INTO food_order(OrderID,FoodID,Quantity, RoomID,Status,DateTime) VALUES ('"+BID+"','"+foodID+"',"+Quantity+","+1+","+0+",'"+date+"');";
                        DataAdder(sql, dbQuery());
                    }
                }
                DialogResult reslult1 = MessageBox.Show("Order Completed", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                if (reslult1 == DialogResult.OK)
                {
                    lblFood.Text = "";
                    lblFTotal.Text = "0.00";
                    num1.Value = 1;
                    tbleOrderDetails.Rows.Clear();


                }
            }
        }

        private void tbleOrderDetails_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
    
    
    
    
    //from main
}
