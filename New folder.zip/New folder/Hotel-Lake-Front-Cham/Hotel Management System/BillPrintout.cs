﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotel_Management_System
{
    public partial class BillPrintout : Form
    {
        public BillPrintout()
        {
            InitializeComponent();
        }

        private void BillPrintout_Load(object sender, EventArgs e)
        {

        }
    }
}
