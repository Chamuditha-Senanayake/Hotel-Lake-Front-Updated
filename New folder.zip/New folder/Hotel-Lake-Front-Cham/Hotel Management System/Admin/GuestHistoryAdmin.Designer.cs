﻿
namespace Hotel_Management_System
{
    partial class GuestHistoryAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelGuestDetails = new System.Windows.Forms.Panel();
            this.cbForeign = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioMale = new System.Windows.Forms.RadioButton();
            this.radioFemale = new System.Windows.Forms.RadioButton();
            this.lblCount = new System.Windows.Forms.Label();
            this.lblDdate = new System.Windows.Forms.Label();
            this.lblAdate = new System.Windows.Forms.Label();
            this.lblRoomType = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.RichTextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbPets = new System.Windows.Forms.CheckBox();
            this.cbEBed = new System.Windows.Forms.CheckBox();
            this.cbHotW = new System.Windows.Forms.CheckBox();
            this.cbSatTV = new System.Windows.Forms.CheckBox();
            this.cbFullPckge = new System.Windows.Forms.CheckBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboID = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tblGuestDetails = new System.Windows.Forms.DataGridView();
            this.label7 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lblIDType = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.btnReset = new FontAwesome.Sharp.IconButton();
            this.label18 = new System.Windows.Forms.Label();
            this.btnUpdate = new FontAwesome.Sharp.IconButton();
            this.label19 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtTP = new System.Windows.Forms.TextBox();
            this.txtFullName = new System.Windows.Forms.TextBox();
            this.txtFName = new System.Windows.Forms.TextBox();
            this.txtID = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panelGuestDetails.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblGuestDetails)).BeginInit();
            this.SuspendLayout();
            // 
            // panelGuestDetails
            // 
            this.panelGuestDetails.Controls.Add(this.cbForeign);
            this.panelGuestDetails.Controls.Add(this.groupBox2);
            this.panelGuestDetails.Controls.Add(this.lblCount);
            this.panelGuestDetails.Controls.Add(this.lblDdate);
            this.panelGuestDetails.Controls.Add(this.lblAdate);
            this.panelGuestDetails.Controls.Add(this.lblRoomType);
            this.panelGuestDetails.Controls.Add(this.txtAddress);
            this.panelGuestDetails.Controls.Add(this.label32);
            this.panelGuestDetails.Controls.Add(this.groupBox1);
            this.panelGuestDetails.Controls.Add(this.label29);
            this.panelGuestDetails.Controls.Add(this.label35);
            this.panelGuestDetails.Controls.Add(this.label28);
            this.panelGuestDetails.Controls.Add(this.label34);
            this.panelGuestDetails.Controls.Add(this.label2);
            this.panelGuestDetails.Controls.Add(this.comboID);
            this.panelGuestDetails.Controls.Add(this.label1);
            this.panelGuestDetails.Controls.Add(this.tblGuestDetails);
            this.panelGuestDetails.Controls.Add(this.label7);
            this.panelGuestDetails.Controls.Add(this.dateTimePicker1);
            this.panelGuestDetails.Controls.Add(this.lblIDType);
            this.panelGuestDetails.Controls.Add(this.label17);
            this.panelGuestDetails.Controls.Add(this.btnReset);
            this.panelGuestDetails.Controls.Add(this.label18);
            this.panelGuestDetails.Controls.Add(this.btnUpdate);
            this.panelGuestDetails.Controls.Add(this.label19);
            this.panelGuestDetails.Controls.Add(this.label39);
            this.panelGuestDetails.Controls.Add(this.txtEmail);
            this.panelGuestDetails.Controls.Add(this.txtTP);
            this.panelGuestDetails.Controls.Add(this.txtFullName);
            this.panelGuestDetails.Controls.Add(this.txtFName);
            this.panelGuestDetails.Controls.Add(this.txtID);
            this.panelGuestDetails.Controls.Add(this.panel2);
            this.panelGuestDetails.Controls.Add(this.label27);
            this.panelGuestDetails.Controls.Add(this.label26);
            this.panelGuestDetails.Controls.Add(this.label25);
            this.panelGuestDetails.Controls.Add(this.label24);
            this.panelGuestDetails.Controls.Add(this.label23);
            this.panelGuestDetails.Controls.Add(this.label22);
            this.panelGuestDetails.Controls.Add(this.panel3);
            this.panelGuestDetails.Location = new System.Drawing.Point(1, 0);
            this.panelGuestDetails.Name = "panelGuestDetails";
            this.panelGuestDetails.Size = new System.Drawing.Size(1006, 582);
            this.panelGuestDetails.TabIndex = 0;
            // 
            // cbForeign
            // 
            this.cbForeign.AutoSize = true;
            this.cbForeign.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbForeign.Location = new System.Drawing.Point(719, 164);
            this.cbForeign.Name = "cbForeign";
            this.cbForeign.Size = new System.Drawing.Size(78, 21);
            this.cbForeign.TabIndex = 358;
            this.cbForeign.Text = "Foreign";
            this.cbForeign.UseVisualStyleBackColor = true;
            this.cbForeign.Enter += new System.EventHandler(this.cbForeign_Enter);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioMale);
            this.groupBox2.Controls.Add(this.radioFemale);
            this.groupBox2.Location = new System.Drawing.Point(565, 256);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(175, 35);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // radioMale
            // 
            this.radioMale.AutoSize = true;
            this.radioMale.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioMale.Location = new System.Drawing.Point(6, 10);
            this.radioMale.Name = "radioMale";
            this.radioMale.Size = new System.Drawing.Size(72, 28);
            this.radioMale.TabIndex = 359;
            this.radioMale.TabStop = true;
            this.radioMale.Text = "Male";
            this.radioMale.UseVisualStyleBackColor = true;
            // 
            // radioFemale
            // 
            this.radioFemale.AutoSize = true;
            this.radioFemale.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioFemale.Location = new System.Drawing.Point(94, 10);
            this.radioFemale.Name = "radioFemale";
            this.radioFemale.Size = new System.Drawing.Size(95, 28);
            this.radioFemale.TabIndex = 358;
            this.radioFemale.TabStop = true;
            this.radioFemale.Text = "Female";
            this.radioFemale.UseVisualStyleBackColor = true;
            // 
            // lblCount
            // 
            this.lblCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCount.Location = new System.Drawing.Point(563, 124);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(111, 33);
            this.lblCount.TabIndex = 357;
            // 
            // lblDdate
            // 
            this.lblDdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDdate.Location = new System.Drawing.Point(563, 88);
            this.lblDdate.Name = "lblDdate";
            this.lblDdate.Size = new System.Drawing.Size(226, 33);
            this.lblDdate.TabIndex = 356;
            // 
            // lblAdate
            // 
            this.lblAdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdate.Location = new System.Drawing.Point(563, 52);
            this.lblAdate.Name = "lblAdate";
            this.lblAdate.Size = new System.Drawing.Size(188, 33);
            this.lblAdate.TabIndex = 355;
            // 
            // lblRoomType
            // 
            this.lblRoomType.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRoomType.Location = new System.Drawing.Point(563, 15);
            this.lblRoomType.Name = "lblRoomType";
            this.lblRoomType.Size = new System.Drawing.Size(202, 35);
            this.lblRoomType.TabIndex = 354;
            // 
            // txtAddress
            // 
            this.txtAddress.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.txtAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtAddress.Location = new System.Drawing.Point(567, 387);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(409, 43);
            this.txtAddress.TabIndex = 15;
            this.txtAddress.Text = "";
            this.txtAddress.Enter += new System.EventHandler(this.txtAddress_Enter);
            // 
            // label32
            // 
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(423, 124);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(111, 33);
            this.label32.TabIndex = 352;
            this.label32.Text = "Days :";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbPets);
            this.groupBox1.Controls.Add(this.cbEBed);
            this.groupBox1.Controls.Add(this.cbHotW);
            this.groupBox1.Controls.Add(this.cbSatTV);
            this.groupBox1.Controls.Add(this.cbFullPckge);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.groupBox1.Location = new System.Drawing.Point(795, 11);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(189, 169);
            this.groupBox1.TabIndex = 342;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Other Facilities";
            // 
            // cbPets
            // 
            this.cbPets.AutoSize = true;
            this.cbPets.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbPets.Location = new System.Drawing.Point(155, 137);
            this.cbPets.Name = "cbPets";
            this.cbPets.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.cbPets.Size = new System.Drawing.Size(18, 17);
            this.cbPets.TabIndex = 8;
            this.cbPets.UseVisualStyleBackColor = true;
            // 
            // cbEBed
            // 
            this.cbEBed.AutoSize = true;
            this.cbEBed.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbEBed.Location = new System.Drawing.Point(155, 113);
            this.cbEBed.Name = "cbEBed";
            this.cbEBed.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.cbEBed.Size = new System.Drawing.Size(18, 17);
            this.cbEBed.TabIndex = 7;
            this.cbEBed.UseVisualStyleBackColor = true;
            // 
            // cbHotW
            // 
            this.cbHotW.AutoSize = true;
            this.cbHotW.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbHotW.Location = new System.Drawing.Point(155, 89);
            this.cbHotW.Name = "cbHotW";
            this.cbHotW.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.cbHotW.Size = new System.Drawing.Size(18, 17);
            this.cbHotW.TabIndex = 6;
            this.cbHotW.UseVisualStyleBackColor = true;
            // 
            // cbSatTV
            // 
            this.cbSatTV.AutoSize = true;
            this.cbSatTV.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbSatTV.Location = new System.Drawing.Point(155, 65);
            this.cbSatTV.Name = "cbSatTV";
            this.cbSatTV.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.cbSatTV.Size = new System.Drawing.Size(18, 17);
            this.cbSatTV.TabIndex = 5;
            this.cbSatTV.UseVisualStyleBackColor = true;
            // 
            // cbFullPckge
            // 
            this.cbFullPckge.AutoSize = true;
            this.cbFullPckge.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbFullPckge.Location = new System.Drawing.Point(155, 41);
            this.cbFullPckge.Name = "cbFullPckge";
            this.cbFullPckge.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.cbFullPckge.Size = new System.Drawing.Size(18, 17);
            this.cbFullPckge.TabIndex = 4;
            this.cbFullPckge.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(18, 87);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(169, 17);
            this.label12.TabIndex = 3;
            this.label12.Text = "Hot Water";
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(18, 38);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(169, 25);
            this.label13.TabIndex = 224;
            this.label13.Text = "Full Package";
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(18, 63);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(159, 19);
            this.label14.TabIndex = 225;
            this.label14.Text = "Satellite TV";
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(18, 111);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(169, 19);
            this.label15.TabIndex = 227;
            this.label15.Text = "Extra Bed";
            // 
            // label20
            // 
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(18, 135);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(169, 19);
            this.label20.TabIndex = 228;
            this.label20.Text = "Pets Allowed";
            // 
            // label29
            // 
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(423, 88);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(111, 33);
            this.label29.TabIndex = 351;
            this.label29.Text = "To :";
            // 
            // label35
            // 
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label35.Location = new System.Drawing.Point(11, 81);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(185, 19);
            this.label35.TabIndex = 341;
            this.label35.Text = "Select Date";
            // 
            // label28
            // 
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(423, 52);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(111, 33);
            this.label28.TabIndex = 350;
            this.label28.Text = "From :";
            // 
            // label34
            // 
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label34.Location = new System.Drawing.Point(12, 11);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(185, 19);
            this.label34.TabIndex = 340;
            this.label34.Text = "Select NIC or Passport No";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(424, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 34);
            this.label2.TabIndex = 349;
            this.label2.Text = "Room Type :";
            // 
            // comboID
            // 
            this.comboID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboID.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboID.FormattingEnabled = true;
            this.comboID.Location = new System.Drawing.Point(13, 33);
            this.comboID.Name = "comboID";
            this.comboID.Size = new System.Drawing.Size(338, 39);
            this.comboID.TabIndex = 1;
            this.comboID.TextChanged += new System.EventHandler(this.comboID_TextChanged);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(423, 264);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 29);
            this.label1.TabIndex = 348;
            this.label1.Text = "Gender :";
            // 
            // tblGuestDetails
            // 
            this.tblGuestDetails.AllowUserToAddRows = false;
            this.tblGuestDetails.AllowUserToDeleteRows = false;
            this.tblGuestDetails.AllowUserToResizeColumns = false;
            this.tblGuestDetails.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            this.tblGuestDetails.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.tblGuestDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.tblGuestDetails.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.tblGuestDetails.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(220)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.tblGuestDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.tblGuestDetails.ColumnHeadersHeight = 60;
            this.tblGuestDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.tblGuestDetails.DefaultCellStyle = dataGridViewCellStyle3;
            this.tblGuestDetails.Location = new System.Drawing.Point(12, 176);
            this.tblGuestDetails.Name = "tblGuestDetails";
            this.tblGuestDetails.ReadOnly = true;
            this.tblGuestDetails.RowHeadersVisible = false;
            this.tblGuestDetails.RowHeadersWidth = 51;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.Azure;
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black;
            this.tblGuestDetails.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.tblGuestDetails.RowTemplate.Height = 35;
            this.tblGuestDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.tblGuestDetails.Size = new System.Drawing.Size(373, 388);
            this.tblGuestDetails.TabIndex = 3;
            this.tblGuestDetails.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.tblGuestDetails_CellClick);
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(424, 336);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(114, 34);
            this.label7.TabIndex = 347;
            this.label7.Text = "Email :";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.CalendarMonthBackground = System.Drawing.Color.White;
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(12, 100);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(339, 34);
            this.dateTimePicker1.TabIndex = 2;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            this.dateTimePicker1.Enter += new System.EventHandler(this.dateTimePicker1_Enter);
            // 
            // lblIDType
            // 
            this.lblIDType.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIDType.Location = new System.Drawing.Point(423, 160);
            this.lblIDType.Name = "lblIDType";
            this.lblIDType.Size = new System.Drawing.Size(123, 35);
            this.lblIDType.TabIndex = 346;
            this.lblIDType.Text = "ID :";
            // 
            // label17
            // 
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(423, 296);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(123, 37);
            this.label17.TabIndex = 345;
            this.label17.Text = "Telephone :";
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.btnReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnReset.IconChar = FontAwesome.Sharp.IconChar.None;
            this.btnReset.IconColor = System.Drawing.Color.Black;
            this.btnReset.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnReset.Location = new System.Drawing.Point(795, 513);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(90, 52);
            this.btnReset.TabIndex = 16;
            this.btnReset.Text = "&Reset";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Visible = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(423, 373);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(111, 33);
            this.label18.TabIndex = 344;
            this.label18.Text = "Address :";
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnUpdate.IconChar = FontAwesome.Sharp.IconChar.None;
            this.btnUpdate.IconColor = System.Drawing.Color.Black;
            this.btnUpdate.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnUpdate.Location = new System.Drawing.Point(891, 512);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(90, 52);
            this.btnUpdate.TabIndex = 17;
            this.btnUpdate.Text = "&Update";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Visible = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // label19
            // 
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(423, 232);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(123, 29);
            this.label19.TabIndex = 343;
            this.label19.Text = "Full Name :";
            // 
            // label39
            // 
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(423, 198);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(135, 31);
            this.label39.TabIndex = 342;
            this.label39.Text = "First Name :";
            // 
            // txtEmail
            // 
            this.txtEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtEmail.Location = new System.Drawing.Point(567, 342);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(409, 38);
            this.txtEmail.TabIndex = 14;
            this.txtEmail.Enter += new System.EventHandler(this.txtEmail_Enter);
            // 
            // txtTP
            // 
            this.txtTP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.txtTP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTP.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTP.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtTP.Location = new System.Drawing.Point(565, 299);
            this.txtTP.Name = "txtTP";
            this.txtTP.Size = new System.Drawing.Size(409, 38);
            this.txtTP.TabIndex = 13;
            this.txtTP.Enter += new System.EventHandler(this.txtTP_Enter);
            // 
            // txtFullName
            // 
            this.txtFullName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.txtFullName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFullName.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFullName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtFullName.Location = new System.Drawing.Point(564, 230);
            this.txtFullName.Name = "txtFullName";
            this.txtFullName.Size = new System.Drawing.Size(412, 38);
            this.txtFullName.TabIndex = 11;
            this.txtFullName.Enter += new System.EventHandler(this.txtFullName_Enter);
            // 
            // txtFName
            // 
            this.txtFName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.txtFName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFName.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtFName.Location = new System.Drawing.Point(564, 192);
            this.txtFName.Name = "txtFName";
            this.txtFName.Size = new System.Drawing.Size(412, 38);
            this.txtFName.TabIndex = 10;
            this.txtFName.Enter += new System.EventHandler(this.txtFName_Enter);
            // 
            // txtID
            // 
            this.txtID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.txtID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtID.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtID.Location = new System.Drawing.Point(564, 158);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(149, 38);
            this.txtID.TabIndex = 9;
            this.txtID.Enter += new System.EventHandler(this.txtID_Enter);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panel2.Location = new System.Drawing.Point(399, 445);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(610, 1);
            this.panel2.TabIndex = 298;
            // 
            // label27
            // 
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(592, 531);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(111, 33);
            this.label27.TabIndex = 325;
            this.label27.Text = "20000";
            // 
            // label26
            // 
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(590, 498);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(111, 33);
            this.label26.TabIndex = 324;
            this.label26.Text = "100000";
            // 
            // label25
            // 
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(590, 465);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(111, 33);
            this.label25.TabIndex = 323;
            this.label25.Text = "120000";
            // 
            // label24
            // 
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(453, 531);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(111, 33);
            this.label24.TabIndex = 322;
            this.label24.Text = "Remaining";
            // 
            // label23
            // 
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(453, 498);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(111, 33);
            this.label23.TabIndex = 321;
            this.label23.Text = "Paid";
            // 
            // label22
            // 
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(452, 465);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(111, 33);
            this.label22.TabIndex = 320;
            this.label22.Text = "Total Bill";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panel3.Location = new System.Drawing.Point(399, -7);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1, 597);
            this.panel3.TabIndex = 297;
            // 
            // GuestHistoryAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.ClientSize = new System.Drawing.Size(1003, 584);
            this.Controls.Add(this.panelGuestDetails);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Name = "GuestHistoryAdmin";
            this.Text = "Guest History";
            this.Load += new System.EventHandler(this.FormGuestDetails_Load);
            this.panelGuestDetails.ResumeLayout(false);
            this.panelGuestDetails.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblGuestDetails)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelGuestDetails;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtTP;
        private System.Windows.Forms.TextBox txtFullName;
        private System.Windows.Forms.TextBox txtFName;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private FontAwesome.Sharp.IconButton btnReset;
        private FontAwesome.Sharp.IconButton btnUpdate;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.ComboBox comboID;
        private System.Windows.Forms.DataGridView tblGuestDetails;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox cbPets;
        private System.Windows.Forms.CheckBox cbEBed;
        private System.Windows.Forms.CheckBox cbHotW;
        private System.Windows.Forms.CheckBox cbSatTV;
        private System.Windows.Forms.CheckBox cbFullPckge;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblIDType;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.RichTextBox txtAddress;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.Label lblDdate;
        private System.Windows.Forms.Label lblAdate;
        private System.Windows.Forms.Label lblRoomType;
        private System.Windows.Forms.RadioButton radioFemale;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioMale;
        private System.Windows.Forms.CheckBox cbForeign;
    }
}