﻿
namespace Hotel_Management_System
{
    partial class FormGuestDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelGuestDetails = new System.Windows.Forms.Panel();
            this.lblForeign = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.comboID = new System.Windows.Forms.ComboBox();
            this.lblCount = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.lblDdate = new System.Windows.Forms.Label();
            this.lblAdate = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.iconButton3 = new FontAwesome.Sharp.IconButton();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbPets = new System.Windows.Forms.CheckBox();
            this.cbEBed = new System.Windows.Forms.CheckBox();
            this.cbHotW = new System.Windows.Forms.CheckBox();
            this.cbSatTV = new System.Windows.Forms.CheckBox();
            this.cbFullPckge = new System.Windows.Forms.CheckBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblTP = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblFullName = new System.Windows.Forms.Label();
            this.lblRoomType = new System.Windows.Forms.Label();
            this.lblFName = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblIDType = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.tblGuestDetails = new System.Windows.Forms.DataGridView();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panelGuestDetails.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblGuestDetails)).BeginInit();
            this.SuspendLayout();
            // 
            // panelGuestDetails
            // 
            this.panelGuestDetails.Controls.Add(this.lblForeign);
            this.panelGuestDetails.Controls.Add(this.label35);
            this.panelGuestDetails.Controls.Add(this.label34);
            this.panelGuestDetails.Controls.Add(this.comboID);
            this.panelGuestDetails.Controls.Add(this.lblCount);
            this.panelGuestDetails.Controls.Add(this.label32);
            this.panelGuestDetails.Controls.Add(this.lblDdate);
            this.panelGuestDetails.Controls.Add(this.lblAdate);
            this.panelGuestDetails.Controls.Add(this.label29);
            this.panelGuestDetails.Controls.Add(this.label28);
            this.panelGuestDetails.Controls.Add(this.panel2);
            this.panelGuestDetails.Controls.Add(this.iconButton3);
            this.panelGuestDetails.Controls.Add(this.label27);
            this.panelGuestDetails.Controls.Add(this.label26);
            this.panelGuestDetails.Controls.Add(this.label25);
            this.panelGuestDetails.Controls.Add(this.label24);
            this.panelGuestDetails.Controls.Add(this.label23);
            this.panelGuestDetails.Controls.Add(this.label22);
            this.panelGuestDetails.Controls.Add(this.groupBox1);
            this.panelGuestDetails.Controls.Add(this.lblEmail);
            this.panelGuestDetails.Controls.Add(this.lblTP);
            this.panelGuestDetails.Controls.Add(this.lblAddress);
            this.panelGuestDetails.Controls.Add(this.lblGender);
            this.panelGuestDetails.Controls.Add(this.lblFullName);
            this.panelGuestDetails.Controls.Add(this.lblRoomType);
            this.panelGuestDetails.Controls.Add(this.lblFName);
            this.panelGuestDetails.Controls.Add(this.lblID);
            this.panelGuestDetails.Controls.Add(this.label2);
            this.panelGuestDetails.Controls.Add(this.label1);
            this.panelGuestDetails.Controls.Add(this.label7);
            this.panelGuestDetails.Controls.Add(this.lblIDType);
            this.panelGuestDetails.Controls.Add(this.label17);
            this.panelGuestDetails.Controls.Add(this.label18);
            this.panelGuestDetails.Controls.Add(this.label19);
            this.panelGuestDetails.Controls.Add(this.label39);
            this.panelGuestDetails.Controls.Add(this.tblGuestDetails);
            this.panelGuestDetails.Controls.Add(this.dateTimePicker1);
            this.panelGuestDetails.Controls.Add(this.panel3);
            this.panelGuestDetails.Location = new System.Drawing.Point(0, 0);
            this.panelGuestDetails.Name = "panelGuestDetails";
            this.panelGuestDetails.Size = new System.Drawing.Size(1006, 582);
            this.panelGuestDetails.TabIndex = 0;
            // 
            // lblForeign
            // 
            this.lblForeign.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblForeign.Location = new System.Drawing.Point(731, 160);
            this.lblForeign.Name = "lblForeign";
            this.lblForeign.Size = new System.Drawing.Size(59, 26);
            this.lblForeign.TabIndex = 360;
            this.lblForeign.Text = "Foreign";
            // 
            // label35
            // 
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label35.Location = new System.Drawing.Point(12, 81);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(185, 19);
            this.label35.TabIndex = 335;
            this.label35.Text = "Select Date";
            // 
            // label34
            // 
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label34.Location = new System.Drawing.Point(12, 11);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(185, 19);
            this.label34.TabIndex = 334;
            this.label34.Text = "Select NIC or Passport No";
            // 
            // comboID
            // 
            this.comboID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboID.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboID.FormattingEnabled = true;
            this.comboID.Location = new System.Drawing.Point(13, 33);
            this.comboID.Name = "comboID";
            this.comboID.Size = new System.Drawing.Size(339, 39);
            this.comboID.TabIndex = 1;
            this.comboID.TextChanged += new System.EventHandler(this.comboID_TextChanged);
            // 
            // lblCount
            // 
            this.lblCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCount.Location = new System.Drawing.Point(567, 124);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(111, 33);
            this.lblCount.TabIndex = 332;
            // 
            // label32
            // 
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(428, 124);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(111, 33);
            this.label32.TabIndex = 331;
            this.label32.Text = "Days :";
            // 
            // lblDdate
            // 
            this.lblDdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDdate.Location = new System.Drawing.Point(567, 88);
            this.lblDdate.Name = "lblDdate";
            this.lblDdate.Size = new System.Drawing.Size(226, 33);
            this.lblDdate.TabIndex = 330;
            // 
            // lblAdate
            // 
            this.lblAdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdate.Location = new System.Drawing.Point(567, 52);
            this.lblAdate.Name = "lblAdate";
            this.lblAdate.Size = new System.Drawing.Size(188, 33);
            this.lblAdate.TabIndex = 329;
            // 
            // label29
            // 
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(428, 88);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(111, 33);
            this.label29.TabIndex = 328;
            this.label29.Text = "To :";
            // 
            // label28
            // 
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(428, 52);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(111, 33);
            this.label28.TabIndex = 327;
            this.label28.Text = "From :";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panel2.Location = new System.Drawing.Point(399, 445);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(610, 1);
            this.panel2.TabIndex = 298;
            // 
            // iconButton3
            // 
            this.iconButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.iconButton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.iconButton3.IconChar = FontAwesome.Sharp.IconChar.None;
            this.iconButton3.IconColor = System.Drawing.Color.Black;
            this.iconButton3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton3.Location = new System.Drawing.Point(732, 468);
            this.iconButton3.Name = "iconButton3";
            this.iconButton3.Size = new System.Drawing.Size(187, 84);
            this.iconButton3.TabIndex = 326;
            this.iconButton3.Text = "Pay Now";
            this.iconButton3.UseVisualStyleBackColor = false;
            this.iconButton3.Click += new System.EventHandler(this.iconButton3_Click_1);
            // 
            // label27
            // 
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(570, 531);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(111, 33);
            this.label27.TabIndex = 325;
            this.label27.Text = "20000";
            this.label27.Visible = false;
            // 
            // label26
            // 
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(568, 498);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(111, 33);
            this.label26.TabIndex = 324;
            this.label26.Text = "100000";
            this.label26.Visible = false;
            // 
            // label25
            // 
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(568, 465);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(111, 33);
            this.label25.TabIndex = 323;
            this.label25.Text = "120000";
            this.label25.Visible = false;
            // 
            // label24
            // 
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(431, 531);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(111, 33);
            this.label24.TabIndex = 322;
            this.label24.Text = "Remaining";
            this.label24.Visible = false;
            // 
            // label23
            // 
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(431, 498);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(111, 33);
            this.label23.TabIndex = 321;
            this.label23.Text = "Paid";
            this.label23.Visible = false;
            // 
            // label22
            // 
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(430, 465);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(111, 33);
            this.label22.TabIndex = 320;
            this.label22.Text = "Total Bill";
            this.label22.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbPets);
            this.groupBox1.Controls.Add(this.cbEBed);
            this.groupBox1.Controls.Add(this.cbHotW);
            this.groupBox1.Controls.Add(this.cbSatTV);
            this.groupBox1.Controls.Add(this.cbFullPckge);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.groupBox1.Location = new System.Drawing.Point(799, 17);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(189, 169);
            this.groupBox1.TabIndex = 319;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Other Facilities";
            // 
            // cbPets
            // 
            this.cbPets.AutoSize = true;
            this.cbPets.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbPets.Location = new System.Drawing.Point(155, 137);
            this.cbPets.Name = "cbPets";
            this.cbPets.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.cbPets.Size = new System.Drawing.Size(18, 17);
            this.cbPets.TabIndex = 341;
            this.cbPets.UseVisualStyleBackColor = true;
            // 
            // cbEBed
            // 
            this.cbEBed.AutoSize = true;
            this.cbEBed.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbEBed.Location = new System.Drawing.Point(155, 113);
            this.cbEBed.Name = "cbEBed";
            this.cbEBed.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.cbEBed.Size = new System.Drawing.Size(18, 17);
            this.cbEBed.TabIndex = 338;
            this.cbEBed.UseVisualStyleBackColor = true;
            // 
            // cbHotW
            // 
            this.cbHotW.AutoSize = true;
            this.cbHotW.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbHotW.Location = new System.Drawing.Point(155, 89);
            this.cbHotW.Name = "cbHotW";
            this.cbHotW.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.cbHotW.Size = new System.Drawing.Size(18, 17);
            this.cbHotW.TabIndex = 339;
            this.cbHotW.UseVisualStyleBackColor = true;
            // 
            // cbSatTV
            // 
            this.cbSatTV.AutoSize = true;
            this.cbSatTV.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbSatTV.Location = new System.Drawing.Point(155, 65);
            this.cbSatTV.Name = "cbSatTV";
            this.cbSatTV.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.cbSatTV.Size = new System.Drawing.Size(18, 17);
            this.cbSatTV.TabIndex = 340;
            this.cbSatTV.UseVisualStyleBackColor = true;
            // 
            // cbFullPckge
            // 
            this.cbFullPckge.AutoSize = true;
            this.cbFullPckge.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbFullPckge.Location = new System.Drawing.Point(155, 41);
            this.cbFullPckge.Name = "cbFullPckge";
            this.cbFullPckge.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.cbFullPckge.Size = new System.Drawing.Size(18, 17);
            this.cbFullPckge.TabIndex = 336;
            this.cbFullPckge.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(18, 87);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(169, 17);
            this.label12.TabIndex = 226;
            this.label12.Text = "Hot Water";
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(18, 38);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(169, 25);
            this.label13.TabIndex = 224;
            this.label13.Text = "Full Package";
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(18, 63);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(159, 19);
            this.label14.TabIndex = 225;
            this.label14.Text = "Satellite TV";
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(18, 111);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(169, 19);
            this.label15.TabIndex = 227;
            this.label15.Text = "Extra Bed";
            // 
            // label20
            // 
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(18, 135);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(169, 19);
            this.label20.TabIndex = 228;
            this.label20.Text = "Pets Allowed";
            // 
            // lblEmail
            // 
            this.lblEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(567, 336);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(419, 35);
            this.lblEmail.TabIndex = 318;
            // 
            // lblTP
            // 
            this.lblTP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTP.Location = new System.Drawing.Point(567, 296);
            this.lblTP.Name = "lblTP";
            this.lblTP.Size = new System.Drawing.Size(158, 35);
            this.lblTP.TabIndex = 317;
            // 
            // lblAddress
            // 
            this.lblAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddress.Location = new System.Drawing.Point(567, 373);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(424, 64);
            this.lblAddress.TabIndex = 316;
            // 
            // lblGender
            // 
            this.lblGender.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGender.Location = new System.Drawing.Point(567, 264);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(158, 35);
            this.lblGender.TabIndex = 315;
            // 
            // lblFullName
            // 
            this.lblFullName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFullName.Location = new System.Drawing.Point(567, 230);
            this.lblFullName.Name = "lblFullName";
            this.lblFullName.Size = new System.Drawing.Size(424, 35);
            this.lblFullName.TabIndex = 314;
            // 
            // lblRoomType
            // 
            this.lblRoomType.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRoomType.Location = new System.Drawing.Point(567, 15);
            this.lblRoomType.Name = "lblRoomType";
            this.lblRoomType.Size = new System.Drawing.Size(202, 35);
            this.lblRoomType.TabIndex = 313;
            // 
            // lblFName
            // 
            this.lblFName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFName.Location = new System.Drawing.Point(567, 193);
            this.lblFName.Name = "lblFName";
            this.lblFName.Size = new System.Drawing.Size(296, 35);
            this.lblFName.TabIndex = 312;
            // 
            // lblID
            // 
            this.lblID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblID.Location = new System.Drawing.Point(567, 160);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(158, 35);
            this.lblID.TabIndex = 311;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(429, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(148, 34);
            this.label2.TabIndex = 310;
            this.label2.Text = "Room Type :";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(428, 264);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 29);
            this.label1.TabIndex = 309;
            this.label1.Text = "Gender :";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(429, 336);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(114, 34);
            this.label7.TabIndex = 308;
            this.label7.Text = "Email :";
            // 
            // lblIDType
            // 
            this.lblIDType.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIDType.Location = new System.Drawing.Point(428, 160);
            this.lblIDType.Name = "lblIDType";
            this.lblIDType.Size = new System.Drawing.Size(143, 35);
            this.lblIDType.TabIndex = 307;
            this.lblIDType.Text = "National ID :";
            // 
            // label17
            // 
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(428, 296);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(143, 37);
            this.label17.TabIndex = 306;
            this.label17.Text = "Telephone :";
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(428, 373);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(111, 33);
            this.label18.TabIndex = 305;
            this.label18.Text = "Address :";
            // 
            // label19
            // 
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(428, 232);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(143, 29);
            this.label19.TabIndex = 304;
            this.label19.Text = "Full Name :";
            // 
            // label39
            // 
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(428, 198);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(143, 31);
            this.label39.TabIndex = 303;
            this.label39.Text = "First Name :";
            // 
            // tblGuestDetails
            // 
            this.tblGuestDetails.AllowUserToAddRows = false;
            this.tblGuestDetails.AllowUserToDeleteRows = false;
            this.tblGuestDetails.AllowUserToResizeColumns = false;
            this.tblGuestDetails.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            this.tblGuestDetails.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.tblGuestDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.tblGuestDetails.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.tblGuestDetails.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(220)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.tblGuestDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.tblGuestDetails.ColumnHeadersHeight = 60;
            this.tblGuestDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.tblGuestDetails.DefaultCellStyle = dataGridViewCellStyle3;
            this.tblGuestDetails.Location = new System.Drawing.Point(13, 176);
            this.tblGuestDetails.Name = "tblGuestDetails";
            this.tblGuestDetails.ReadOnly = true;
            this.tblGuestDetails.RowHeadersVisible = false;
            this.tblGuestDetails.RowHeadersWidth = 51;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.Azure;
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black;
            this.tblGuestDetails.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.tblGuestDetails.RowTemplate.Height = 35;
            this.tblGuestDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.tblGuestDetails.Size = new System.Drawing.Size(373, 388);
            this.tblGuestDetails.TabIndex = 3;
            this.tblGuestDetails.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.tblGuestDetails_CellClick);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.CalendarMonthBackground = System.Drawing.Color.White;
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(13, 100);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(339, 34);
            this.dateTimePicker1.TabIndex = 2;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            this.dateTimePicker1.Enter += new System.EventHandler(this.dateTimePicker1_Enter);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panel3.Location = new System.Drawing.Point(399, -7);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1, 597);
            this.panel3.TabIndex = 297;
            // 
            // FormGuestDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.ClientSize = new System.Drawing.Size(1003, 584);
            this.Controls.Add(this.panelGuestDetails);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Name = "FormGuestDetails";
            this.Text = "Guest Details";
            this.Load += new System.EventHandler(this.FormGuestDetails_Load);
            this.panelGuestDetails.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblGuestDetails)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelGuestDetails;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label lblDdate;
        private System.Windows.Forms.Label lblAdate;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Panel panel2;
        private FontAwesome.Sharp.IconButton iconButton3;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblTP;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label lblFullName;
        private System.Windows.Forms.Label lblRoomType;
        private System.Windows.Forms.Label lblFName;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblIDType;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.DataGridView tblGuestDetails;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.ComboBox comboID;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.CheckBox cbPets;
        private System.Windows.Forms.CheckBox cbEBed;
        private System.Windows.Forms.CheckBox cbHotW;
        private System.Windows.Forms.CheckBox cbSatTV;
        private System.Windows.Forms.CheckBox cbFullPckge;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblForeign;
    }
}